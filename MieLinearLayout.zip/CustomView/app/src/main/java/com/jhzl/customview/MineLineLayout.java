package com.jhzl.customview;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;

public class MineLineLayout extends ViewGroup {
    public static final int HORIZONTAL = 0;
    public static final int VERTICAL = 1;
    private int mOrientation = VERTICAL;
    public static final String TAG = MineLineLayout.class.getSimpleName();

    public MineLineLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        final TypedArray a = context.obtainStyledAttributes(
                attrs, R.styleable.MineLineLayout);
        int index = a.getInt(R.styleable.MineLineLayout_android_orientation, -1);
        if (index >= 0) {
            setOrientation(index);
        }
        a.recycle();
        Log.d(TAG,"orientation = "+index);
    }


    public void setOrientation(int orientation) {
        this.mOrientation = orientation;
    }


    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        if (mOrientation  == VERTICAL){
            verticalLayout();
        }else{
            horizontalLayout();
        }
    }

    private void horizontalLayout() {
        int curLeft = 0;
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            VerticalLayoutParams layoutParams = (VerticalLayoutParams) child.getLayoutParams();
            curLeft = curLeft + layoutParams.leftMargin;
            child.layout(curLeft, 0, curLeft+child.getMeasuredWidth(),  child.getMeasuredHeight());
            curLeft = curLeft + child.getMeasuredWidth();
        }
    }

    private void verticalLayout() {
        int curTop = 0;
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            VerticalLayoutParams layoutParams = (VerticalLayoutParams) child.getLayoutParams();
            curTop = curTop + layoutParams.topMargin;
            child.layout(0, curTop, child.getMeasuredWidth(), curTop + child.getMeasuredHeight());
            curTop = curTop + child.getMeasuredHeight();
        }
    }

    public static class VerticalLayoutParams extends MarginLayoutParams {

        public VerticalLayoutParams(Context c, AttributeSet attrs) {
            super(c, attrs);
        }

        public VerticalLayoutParams(int width, int height) {
            super(width, height);
        }

        public VerticalLayoutParams(LayoutParams lp) {
            super(lp);
        }
    }

    @Override
    public LayoutParams generateLayoutParams(AttributeSet attrs) {
        return new VerticalLayoutParams(getContext(), attrs);
    }

    @Override
    protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams lp) {
        return new VerticalLayoutParams(lp);
    }

    @Override
    protected LayoutParams generateDefaultLayoutParams() {
        return new VerticalLayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
    }


    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        if (mOrientation == VERTICAL){
            measureVertical(widthMeasureSpec, heightMeasureSpec);
        }else{
            measureHorizontal(widthMeasureSpec,heightMeasureSpec);
        }
    }

    private void measureHorizontal(int widthMeasureSpec, int heightMeasureSpec) {
        int totalHeight = 0;
        int totalWidth = 0;
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            measureChild(child, widthMeasureSpec, heightMeasureSpec);
            //计算最大高度
            totalHeight = Math.max(totalHeight,child.getMeasuredHeight());
            MarginLayoutParams layoutParams = (MarginLayoutParams) child.getLayoutParams();
            //计算总宽度
            totalWidth = totalWidth + ((MarginLayoutParams) layoutParams).leftMargin+child.getMeasuredWidth();
        }
        Log.d(TAG,"totalWidth = "+totalWidth+"  totalHeight = "+totalHeight);
        setMeasuredDimension(totalWidth, totalHeight);
    }

    private void measureVertical(int widthMeasureSpec, int heightMeasureSpec) {
        int totalHeight = 0;
        int totalWidth = 0;
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            measureChild(child, widthMeasureSpec, heightMeasureSpec);
            //计算总共高度
            totalHeight = child.getMeasuredHeight() + totalHeight;
            MarginLayoutParams layoutParams = (MarginLayoutParams) child.getLayoutParams();
            totalHeight = totalHeight + ((MarginLayoutParams) layoutParams).topMargin;
            //取最大的子view的宽度
            totalWidth = Math.max(child.getMeasuredWidth(), totalWidth);
        }
        float xmlMaxWidth = getResources().getDimension(R.dimen.dp250);
        float xmlMaxHeight = getResources().getDimension(R.dimen.dp100);
        Log.d(TAG, "measureVertical = " + xmlMaxWidth + "   xmlMaxHeight = " + xmlMaxHeight + "     totalWidth = " + (totalWidth) + "  totalHeight = " + totalHeight);
        setMeasuredDimension(totalWidth, totalHeight);
    }

    private void justMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int totalHeight = 0;
        int totalWidth = 0;
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            measureChild(child, widthMeasureSpec, heightMeasureSpec);
            //计算总共高度
            totalHeight = child.getMeasuredHeight() + totalHeight;
            //取最大的子view的宽度
            totalWidth = Math.max(child.getMeasuredWidth(), totalWidth);
        }
        float xmlMaxWidth = getResources().getDimension(R.dimen.dp250);
        float xmlMaxHeight = getResources().getDimension(R.dimen.dp100);
        Log.d(TAG, "xmlMaxWidth = " + xmlMaxWidth + "   xmlMaxHeight = " + xmlMaxHeight + "     totalWidth = " + (totalWidth) + "  totalHeight = " + totalHeight);
        setMeasuredDimension(totalWidth, totalHeight);
    }
}
